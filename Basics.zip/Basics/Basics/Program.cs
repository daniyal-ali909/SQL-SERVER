﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("Hello, World!");

//string firstName = "Daniyal";
//string lastName = "Sajid";

//Console.WriteLine("student of the month for the month of December" + " is " + firstName + " " + lastName);

//Datatypes

byte age = 19;

short salary = 28000;

int price = 2147483647;

long longNum = 9223372036854L;

float deciNum = 75.33F;

double dNum = 100.54D;

decimal price2 = 6999.95M;

//string

char alpha = 'A';

string car = "Supra";

bool isAffordable = false;

Console.WriteLine("Age is " + age + "\nSalary is " + salary + "\nPrice is " + price + "\nLong Number is" + longNum
    + "\nDeci Number is" + deciNum + "\nDouble Number is" + dNum + "\nPrice2 is" + price + "\nCharacter is " + alpha
    + "\nString is " + car + "\nBool is isAffordable " + isAffordable);

//Arithametic operator

Console.WriteLine(85 + 60);
Console.WriteLine(85 - 60);
Console.WriteLine(85 * 60);
Console.WriteLine(85 / 60);
Console.WriteLine(85 % 60);

//ShortCut

int number = 10;

Console.WriteLine(number += 5);
Console.WriteLine(number -= 5);
Console.WriteLine(number *= 5);
Console.WriteLine(number /= 5);


//Comparison operator

int num1 = 50; int num2 = 80;
Console.WriteLine(num1 == num2); //F
Console.WriteLine(num1 >= num2); //F
Console.WriteLine(num1 <= num2); //T
Console.WriteLine(num1 != num2); //T
Console.WriteLine(num1 < num2); //T
Console.WriteLine(num1 > num2); //F

